"""Replay real browser receipts into synthetic downstream v1 consumers.
No production upstream/verify Skill is claimed to have run.
"""
import copy, json, hashlib
from pathlib import Path
from jsonschema import Draft202012Validator,FormatChecker
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
source_path=Path(read(ROOT/'aftercare-interact/references/provenance.json')['sources'][0]['path'])
central=read(source_path);defs={}
def collect(name):
 if name in defs:return
 defs[name]=central['$defs'][name]
 def walk(x):
  if isinstance(x,dict):
   if '$ref' in x:collect(x['$ref'].split('/')[-1])
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(defs[name])
for name in ('TaskIntent','OrderSelection','RemedyPlan','EvidenceBundle','InteractionPlan','ExecutionReceipt','OperationLedger','PlatformView','TaskSnapshot','aftercare-verifyRequest','aftercare-verifyResult'):collect(name)
bundle={'$schema':central['$schema'],'$defs':defs}
(ROOT/'browser-tests/handoff.schema.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2),encoding='utf-8')
def valid(name,data):Draft202012Validator({**bundle,'$ref':'#/$defs/'+name},format_checker=FormatChecker()).validate(data)
report=read(ROOT/'browser-tests/results.json');trace=report['host']['trace']
plans={e['proposal_id']:e for e in trace if e['kind']=='skill_plan_fixture'}
receipts={e['receipt']['execution_id']:e['receipt'] for e in trace if e['kind']=='execution_receipt'}
observations={e['observation']['observation_id']:e['observation'] for e in trace if e['kind']=='browser_observation'}
cases=[]
for e in trace:
 if e['kind']!='synthetic_verification':continue
 receipt=receipts[e['execution_id']];plan=plans[receipt['proposal_id']];obs=observations[e['outcome']['evidence_ref']];q=plan['request'];task=q['task_id'];operation=plan['result']['data']['actions'][0]['operation']
 expected=plan['result']['data']['actions'][0]['expected_result']
 valid('InteractionPlan',plan['result']['data']);valid('ExecutionReceipt',receipt)
 observed_controls=[]
 for c in obs['controls']:
  observed_controls.append({'control_ref':'browser-'+c['key'],'semantic_role':c['role'],'visible_label':c['label'],'observation_id':obs['observation_id'],'page_revision':obs['revision'],'effect':'unknown','evidence_refs':[obs['observation_id']]})
 view={'platform_key':'platform-sandbox','environment':'sandbox','page_kind':'aftersales','supported_operations':[],'unsupported_operations':[],'state_facts':[{'key':'observed-result','value':obs['result_text'] or '当前合成页面已观察','evidence_refs':[obs['observation_id']],'certainty':'observed'}],'rules':[],'controls':observed_controls,'expires_on_page_change':True}
 ledger={'task_id':task,'ledger_revision':1,'events':[{'event_id':'event-'+receipt['execution_id'],'occurred_at':receipt['finished_at'],'event_type':'tool_returned','execution_ref':receipt['execution_id'],'evidence_refs':[obs['observation_id']]}]}
 request={**q,'skill_id':'aftercare-verify','call_id':'verify-'+receipt['execution_id'],'inputs':{'platform_view':{'artifact_id':'view-'+receipt['execution_id'],'kind':'PlatformView','revision':1},'receipt':{'artifact_id':receipt['execution_id'],'kind':'ExecutionReceipt','revision':1},'ledger':{'artifact_id':'ledger-'+receipt['execution_id'],'kind':'OperationLedger','revision':1}}}
 success=e['outcome']['effect_result']=='confirmed_success'
 state={'submit':'submitted','book_pickup':'pickup_booked','withdraw':'closed'}.get(operation,'draft') if success else 'unknown'
 outcome={'platform_state':state,'effect_result':'confirmed_success' if success else 'unknown','stage_complete':success,'case_terminal':False,'business_result':'not_final','actual_receipt_confirmed':'unknown','evidence_refs':[obs['observation_id']],'user_todos':[]}
 result={'contract_version':'1.0.0','skill_id':'aftercare-verify','call_id':request['call_id'],'task_id':task,'based_on_task_revision':4,'status':'completed','data':outcome,'questions':[],'issues':[],'user_message':'本次页面操作已核对，尚不表示退款完成。' if success else '还没有看到预期结果，请勿重复操作。'}
 for name,data in [('PlatformView',view),('OperationLedger',ledger),('aftercare-verifyRequest',request),('aftercare-verifyResult',result)]:valid(name,data)
 registry=copy.deepcopy(plan['resolved_context']['registry'])
 for item in q['inputs']['source_artifacts']+[q['task_snapshot']]:
  registered=registry[item['artifact_id']]
  assert registered['task_id']==task and registered['revision']==item['revision'] and registered['kind']==item['kind']
  valid(item['kind'],registered['data'])
 for ref,data in [(request['inputs']['platform_view'],view),(request['inputs']['receipt'],receipt),(request['inputs']['ledger'],ledger)]:
  registry[ref['artifact_id']]={'kind':ref['kind'],'revision':ref['revision'],'task_id':task,'accessible':True,'current':True,'data':data}
 for ref in [request['task_snapshot'],*request['inputs'].values()]:
  row=registry[ref['artifact_id']];assert row['task_id']==task and row['revision']==ref['revision'] and row['kind']==ref['kind']
 cases.append({'execution_id':receipt['execution_id'],'request':request,'artifact_registry':registry,'resolved_platform_view':view,'receipt':receipt,'ledger':ledger,'immutable_plan':plan['result']['data'],'expected_result':expected,'synthetic_verify_result':result,'browser_observation':obs})
# Explicit synthetic upstream bodies, separate from actual incompatible upstream outputs.
base=read(ROOT/'examples/pending-authorization.json');reg=base['host']['registry']
intent={'goal':'合成用户希望将蓝色杯子退回并退款','scope':'single_item_single_case','user_facts':[{'key':'problem','value':'合成用户称杯口有裂纹','certainty':'user_reported','evidence_refs':['ev-page']}],'requested_outcome':'return_refund','missing_fields':[]}
upstream={'TaskIntent':intent,'OrderSelection':reg['order-test']['data'],'RemedyPlan':reg['remedy-test']['data'],'EvidenceBundle':reg['bundle-test']['data']}
for name,data in upstream.items():valid(name,data)
assert any(x['synthetic_verify_result']['data']['effect_result']=='unknown' for x in cases)
assert any(x['synthetic_verify_result']['data']['platform_state']=='submitted' for x in cases)
assert all(x['synthetic_verify_result']['data']['actual_receipt_confirmed']=='unknown' for x in cases)
output={'synthetic_upstream':upstream,'method':'actual browser receipts and observations, author synthetic upstream/downstream consumers','production_integration':False,'source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'verified_handoffs':len(cases),'cases':cases}
(ROOT/'browser-tests/handoff-results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print('Verified browser-to-v1 handoffs:',len(cases),'; synthetic upstream bodies: 4; no refund arrival claims')
