param([string]$WorkDirectory = (Join-Path $PSScriptRoot '..\..\work\browser-replay'))
$ErrorActionPreference = 'Stop'
$testRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$scratchRoot = [IO.Path]::GetFullPath($WorkDirectory)
New-Item -ItemType Directory -Force -Path $scratchRoot | Out-Null
$testCli = Join-Path $env:LOCALAPPDATA 'Tabbit\LocalAgent\bin\tabbit-cli.exe'
if (!(Test-Path -LiteralPath $testCli)) { throw 'Tabbit stable launcher unavailable' }
$existing = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
if ($existing) { throw 'Port 8765 is occupied; do not replace another service.' }
$pythonExe = (Get-Command python).Source
$serverFile = Join-Path $testRoot 'server.py'
$serverArgs = '-B -X utf8 "' + $serverFile + '" --port 8765 --work "' + $scratchRoot + '"'
$serverProcess = Start-Process -FilePath $pythonExe -ArgumentList $serverArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $scratchRoot 'server.log') -RedirectStandardError (Join-Path $scratchRoot 'server-error.log')
$taskName = 'aftercare-interact-test'
try {
    $ready = $false
    for ($i=0; $i -lt 30; $i++) {
        try { $health=Invoke-RestMethod 'http://127.0.0.1:8765/health'; if ($health.synthetic) {$ready=$true;break} } catch {}
        Start-Sleep -Milliseconds 200
    }
    if (!$ready) { throw 'Synthetic server did not start' }
    $program = Join-Path $testRoot 'runner.js'
    $requestId = 'suite-' + [guid]::NewGuid().ToString('N')
    $raw = cmd.exe /d /c "`"$testCli`" nodejs --task $taskName --request-id $requestId --timeout-ms 60000 < `"$program`""
    $raw | Set-Content -LiteralPath (Join-Path $scratchRoot 'cli-result.txt') -Encoding utf8
    $response = ($raw | Where-Object { $_.StartsWith('{') } | Select-Object -Last 1) | ConvertFrom-Json
    if ($response.status -ne 'succeeded') { throw 'Browser run did not finish successfully; inspect the saved receipt before retrying.' }
    Copy-Item -LiteralPath $response.result.value.output -Destination (Join-Path $testRoot 'results.json')
    & $pythonExe -B -X utf8 (Join-Path $testRoot 'check_handoff.py')
    if ($LASTEXITCODE -ne 0) { throw 'Handoff validation failed' }
    Write-Output "Browser checks: $($response.result.value.passed)/$($response.result.value.total)"
} finally {
    # Only task-owned test tabs are closed. Never inventory/claim user tabs.
    $cleanup = Join-Path $scratchRoot 'close-test-tabs.js'
    [IO.File]::WriteAllText($cleanup, 'let n=0; for (const p of pages()) { if (p.url().startsWith("http://127.0.0.1:8765/")) {await p.close();n++} } return {closed:n};', [Text.UTF8Encoding]::new($false))
    cmd.exe /d /c "`"$testCli`" nodejs --task $taskName --request-id cleanup-$requestId < `"$cleanup`"" | Out-Null
    & $testCli finish --task $taskName | Out-Null
    if (!$serverProcess.HasExited) { Stop-Process -Id $serverProcess.Id }
}
