// Run only in Tabbit's owned Node/Playwright runtime. Browser actions are
// centralized in execute(); setup and simulated user takeover are named apart.
const origin = 'http://127.0.0.1:8765';
const rows=[];
const post=async(path,data)=>{const r=await context.request.post(origin+path,{data});const v=await r.json();assert(r.ok(),JSON.stringify(v));return v};
const mark=(name,ok,detail={})=>{rows.push({name,passed:!!ok,...detail});assert(ok,name+' '+JSON.stringify(detail))};
let sequence=0;
async function observe(){
 return await page.evaluate(({sequence})=>{
  const visible=e=>!!(e.getClientRects().length)&&getComputedStyle(e).visibility!=='hidden';
  const controls=Array.from(document.querySelectorAll('[data-control]')).map(e=>{const b=e.getBoundingClientRect();const hit=document.elementFromPoint(b.x+b.width/2,b.y+b.height/2);const shown=visible(e);return {key:e.dataset.control,label:e.getAttribute('aria-label')||e.textContent.trim(),role:e.tagName==='SELECT'?'combobox':e.tagName==='INPUT'&&e.type!=='file'?'textbox':'button',item_ref:e.closest('[data-item]')?.dataset.item||'item-cup',visible:shown,enabled:!e.disabled,occluded:shown&&hit!==e&&!e.contains(hit),value:e.value??null,box:{x:b.x,y:b.y,width:b.width,height:b.height}}});
  return {case_id:new URLSearchParams(location.search).get('case'),url:location.href,observation_id:'browser-obs-'+sequence,revision:Number(document.documentElement.dataset.revision),controls,detail_visible:visible(document.querySelector('#detail')),explanation_visible:visible(document.querySelector('#explanation')),record_id:document.querySelector('#result').dataset.record||null,result_operation:document.querySelector('#result').dataset.operation||null,result_text:document.querySelector('#result').textContent};
 },{sequence:++sequence});
}
async function setup({mode='auto',variant='',detail=false}={}){
 const {case_id}=await post('/case',{mode});
 await page.goto(origin+'/?case='+case_id+'&variant='+variant+'&detail='+(detail?'1':'0'),{waitUntil:'load'});
 return case_id;
}
async function prepare(case_id,key,value=null,extra={}){
 const target=page.locator('[data-control="'+key+'"]');
 if(await target.isVisible())await target.scrollIntoViewIfNeeded();
 return await post('/prepare',{case_id,control:key,value,observation:await observe(),...extra});
}
async function gate(p,token){return await post('/gate',{proposal_id:p.proposal_id,token,observation:await observe()})}
async function execute(p,{authorize=false,verify=true}={}){
 const token=authorize?(await post('/confirm',{proposal_id:p.proposal_id})).token:undefined;
 const permit=await gate(p,token);
 if(!permit.allowed)return {permit};
 const before=await observe();const target=page.locator('[data-control="'+permit.control+'"]');
 // No program-generated plan executes without the host permit above.
 if(permit.operation==='fill'){
   await target.fill(permit.value);
   await target.press('Tab'); // Commit the single field's change event.
 }else if(permit.operation==='select')await target.selectOption(permit.value);
 else if(permit.operation==='attach')await target.setInputFiles({name:permit.value.name,mimeType:'image/png',buffer:Buffer.from(permit.value.base64,'base64')});
 else await target.click({timeout:3000});
 if(p.effect==='external_write')await page.waitForFunction(old=>document.querySelector('#result').dataset.record&&document.querySelector('#result').dataset.record!==old,before.record_id,{timeout:5000});
 const receipt=await post('/returned',{execution_id:permit.execution_id,tool_success:true});
 const after=await observe();
 const outcome=verify?await post('/verify',{execution_id:permit.execution_id,observation:after}):null;
 return {permit,receipt,after,outcome};
}

// Modes and rendered highlighting use the same page and host records.
let cid=await setup({mode:'self'}),p=await prepare(cid,'open');
mark('self_explain_only',p.plan.data.presentation==='explain_only'&&p.plan.data.actions.length===0&&p.plan.data.highlight_control_ref===null);
mark('self_no_execution',!(await gate(p)).allowed&&!(await observe()).detail_visible);
cid=await setup({mode:'guided'});p=await prepare(cid,'open');
mark('guided_plan_no_actions',p.plan.data.actions.length===0&&p.plan.data.presentation==='highlight');
const highlight=await page.evaluate(()=>{const t=document.querySelector('[data-control=open]'),b=t.getBoundingClientRect(),h=document.querySelector('#highlight');Object.assign(h.style,{display:'block',left:(b.x-4)+'px',top:(b.y-4)+'px',width:(b.width+8)+'px',height:(b.height+8)+'px'});return {pointerEvents:getComputedStyle(h).pointerEvents,targetHit:document.elementFromPoint(b.x+b.width/2,b.y+b.height/2)===t}});
mark('guided_rendered_highlight_nonblocking',highlight.pointerEvents==='none'&&highlight.targetHit);
mark('guided_executor_rejects',!(await gate(p)).allowed&&!(await observe()).detail_visible);
// Test-user action, not Skill execution; following observation invalidates the old plan.
await page.locator('[data-item="item-cup"]').getByRole('button',{name:'申请售后',exact:true}).click();
mark('guided_user_action_requires_refresh',!(await gate(p)).allowed&&(await observe()).detail_visible);
mark('highlight_invalidated_after_change',await page.locator('#highlight').evaluate(e=>getComputedStyle(e).display==='none'));

// Same-name buttons: ambiguity is rejected; the registered product-scoped target works.
cid=await setup();p=await prepare(cid,'open',null,{ambiguous:true});
mark('same_name_ambiguous_rejected',!(await gate(p)).allowed);
p=await prepare(cid,'open');let result=await execute(p);
mark('auto_navigation_actual',result.permit.allowed&&result.outcome.effect_result==='confirmed_success');

// Complete synthetic workflow: prepared upstream records -> plan -> gate -> browser
// -> receipt -> new observation -> synthetic verifier. Each next step re-observes.
const chainCase=cid;
const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6rj8AAAAASUVORK5CYII=';
for(const [key,value,authorized] of [['expand',null,false],['local','合成本地备注',false],['option','return_refund',false],['reason','合成说明：杯口有裂纹',true],['photo',{name:'synthetic.png',base64:png},true],['submit',null,true],['withdraw',null,true],['accept',null,true],['pickup',null,true],['message',null,true]]){
 p=await prepare(cid,key,value);
 if(authorized)mark(key+'_no_authorization_rejected',!(await gate(p)).allowed);
 result=await execute(p,{authorize:authorized});
 mark(key+'_actual_browser_and_verification',result.permit.allowed&&result.outcome.effect_result==='confirmed_success',{operation:result.permit.operation,execution_id:result.permit.execution_id});
}
// Browser-visible critical notice is never covered by the renderer. Unsafe geometry cancels.
await page.locator('#critical').scrollIntoViewIfNeeded();
const clear=await page.evaluate(()=>{const n=document.querySelector('#critical').getBoundingClientRect(),h=document.querySelector('#highlight');Object.assign(h.style,{display:'block',left:n.x+'px',top:n.y+'px',width:n.width+'px',height:n.height+'px'});const b=h.getBoundingClientRect();const overlap=b.left<n.right&&b.right>n.left&&b.top<n.bottom&&b.bottom>n.top;if(overlap)h.style.display='none';return overlap&&getComputedStyle(h).display==='none'});
mark('highlight_critical_notice_overlap_cancelled',clear);

for(const variant of ['hidden','disabled','occluded']){
 cid=await setup({variant,detail:true});p=await prepare(cid,'submit');
 const x=await execute(p,{authorize:true});mark(variant+'_native_page_target_rejected',!x.permit.allowed,{errors:x.permit.errors});
}
cid=await setup({detail:true});p=await prepare(cid,'unknown');mark('unknown_effect_rejected',!(await gate(p)).allowed);
cid=await setup({detail:true});p=await prepare(cid,'submit');await page.locator('#manual').click();mark('page_revision_changed_rejected',!(await execute(p,{authorize:true})).permit.allowed);
for(const mode of ['self','guided']){
 cid=await setup({detail:true});p=await prepare(cid,'submit');const c=await post('/confirm',{proposal_id:p.proposal_id});await post('/state',{case_id:cid,changes:{mode}});mark('mode_changed_'+mode,!(await gate(p,c.token)).allowed);
}
cid=await setup({detail:true});p=await prepare(cid,'submit');let consent=await post('/confirm',{proposal_id:p.proposal_id});await post('/state',{case_id:cid,changes:{paused:true}});mark('paused_after_confirmation',!(await gate(p,consent.token)).allowed);
cid=await setup({detail:true});p=await prepare(cid,'submit');consent=await post('/confirm',{proposal_id:p.proposal_id});await post('/mutate-content',{proposal_id:p.proposal_id});mark('content_changed_after_confirmation',!(await gate(p,consent.token)).allowed);
cid=await setup({variant:'injection',detail:true});p=await prepare(cid,'submit');mark('page_injection_no_authority',!(await gate(p)).allowed);
for(const challenge of ['login','captcha','payment']){
 cid=await setup({detail:true});p=await prepare(cid,'submit');await post('/state',{case_id:cid,changes:{challenge}});mark('challenge_'+challenge,!(await execute(p,{authorize:true})).permit.allowed);
}
cid=await setup({detail:true});p=await prepare(cid,'submit');await post('/state',{case_id:cid,changes:{supported:false}});mark('platform_unsupported',!(await execute(p,{authorize:true})).permit.allowed);
cid=await setup({detail:true});p=await prepare(cid,'submit');result=await execute(p,{authorize:true,verify:false});
mark('sent_not_yet_verified',result.receipt.dispatch_state==='sent'&&result.outcome===null);
const retry=await prepare(cid,'submit');mark('new_proposal_same_effect_rejected',retry.proposal_id!==p.proposal_id&&!(await execute(retry,{authorize:true})).permit.allowed);
await post('/verify',{execution_id:result.permit.execution_id,observation:await observe()});
mark('verified_success_still_not_repeated',!(await execute(retry,{authorize:true})).permit.allowed);
cid=await setup({detail:true});p=await prepare(cid,'noop');result=await execute(p);mark('tool_success_without_page_result_is_unknown',result.receipt.tool_state==='succeeded'&&result.outcome.effect_result==='unknown');

const reportResponse=await context.request.get(origin+'/report');const hostReport=await reportResponse.json();
const chainRecords=hostReport.business_records.filter(x=>x.task===chainCase);
mark('merchant_truth_matches_chain',chainRecords.length===7,{operations:chainRecords.map(x=>x.operation)});
mark('merchant_upload_received_actual_bytes',chainRecords.some(x=>x.operation==='attach'&&JSON.parse(x.payload).bytes>0));
const report={synthetic:true,real_browser:true,model_used_in_browser_run:false,executor:'loopback test host; not production authorization',passed:rows.filter(x=>x.passed).length,total:rows.length,checks:rows,host:hostReport};
const output=artifactPath('aftercare-browser-results.json');await(await import('node:fs/promises')).writeFile(output,JSON.stringify(report,null,2),{flag:'wx'});
globalThis.aftercareReport={output,passed:report.passed,total:report.total};
await setup({detail:true});
return globalThis.aftercareReport;
