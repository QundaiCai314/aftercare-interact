"""Validate preserved independent outputs; this script does not call a model."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'aftercare-interact/scripts'))
from validate_plan import validate
def read(p):return json.loads(p.read_text(encoding='utf-8'))
checks=[]
for round in ('round1','round2'):
    inputs=read(ROOT/f'tests/forward-{round}-inputs.json')['cases']
    outputs=read(ROOT/f'tests/forward-{round}-results.json')
    by_id={str(x['id']):x for x in outputs}
    checks.append({'name':round+':complete_ids','passed':len(by_id)==len(outputs)==len(inputs) and set(by_id)=={str(x['id']) for x in inputs}})
    for item in inputs:
        result=by_id[str(item['id'])]['result']
        err=validate(item['request'],result,item['resolved_host_context'])
        checks.append({'name':round+':'+str(item['id']),'passed':not err,'errors':err,'status':result['status'],'action_count':len(result['data']['actions'])})
report={'method':'checks of recorded independent outputs, not a new model call','passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks}
(ROOT/'tests/model-validation-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if report['passed']==report['total'] else 1)
