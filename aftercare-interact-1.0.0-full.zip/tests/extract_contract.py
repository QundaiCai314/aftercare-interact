"""Verify a standalone definition bundle against the unchanged central source.
Usage: python extract_contract.py path/to/contracts.schema.json
The central schema is read only. No automatic migration or rewriting.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
central=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
bundle=json.loads((ROOT/'aftercare-interact/references/interact.schema.json').read_text(encoding='utf-8'))
for k,v in bundle['$defs'].items():
    assert v==central['$defs'][k],k
    def walk(x):
        if isinstance(x,dict):
            if '$ref' in x:assert x['$ref'].split('/')[-1] in bundle['$defs'],x['$ref']
            for y in x.values():walk(y)
        elif isinstance(x,list):
            for y in x:walk(y)
    walk(v)
print('Verified',len(bundle['$defs']),'definitions and all local refs')
