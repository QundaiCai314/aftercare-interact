"""Build and test an unadopted request/result overlay, leaving v1 definitions intact."""
import copy, json
from pathlib import Path
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
defs=read(ROOT/'aftercare-interact/references/interact.schema.json')['$defs']
empty={'maxItems':0}
def plan(props):return {'properties':{'result':{'properties':{'data':{'properties':props}}}}}
def mode(m):return {'properties':{'request':{'properties':{'mode':{'const':m}}}}}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':defs,'type':'object','required':['request','result'],'additionalProperties':False,'properties':{'request':{'$ref':'#/$defs/aftercare-interactRequest'},'result':{'allOf':[{'$ref':'#/$defs/aftercare-interactResult'},{'properties':{'data':{'$ref':'#/$defs/InteractionPlan'}}}]}},'allOf':[plan({'actions':{'maxItems':1}}),{'if':mode('self'),'then':plan({'presentation':{'const':'explain_only'},'actions':empty,'highlight_control_ref':{'type':'null'}})},{'if':mode('guided'),'then':plan({'actions':empty,'presentation':{'enum':['explain_only','highlight']}})},{'if':plan({'refresh_required':{'const':True}}),'then':plan({'actions':empty,'highlight_control_ref':{'type':'null'}})},{'if':plan({'presentation':{'const':'propose_action'}}),'then':plan({'actions':{'minItems':1,'maxItems':1}}),'else':plan({'actions':empty})},{'if':plan({'presentation':{'const':'highlight'}}),'then':plan({'highlight_control_ref':{'type':'string'}})},{'if':plan({'presentation':{'const':'explain_only'}}),'then':plan({'highlight_control_ref':{'type':'null'}})},{'if':{'properties':{'result':{'properties':{'status':{'not':{'const':'completed'}}}}}},'then':plan({'actions':empty})}]}
save(ROOT/'candidate/interaction-pair.schema.json',schema)
v=Draft202012Validator(schema);rows=[]
def test(name,obj,want):
    passed=v.is_valid(obj)==want;rows.append({'name':name,'passed':passed});assert passed,name
def pair(m):return {k:read(ROOT/f'examples/{m}-{k}.json') for k in ('request','result')}
for m in ('self','guided','auto'):test(m,pair(m),True)
p=pair('auto');p['result']['data']['actions']*=2;test('multiple',p,False);save(ROOT/'candidate/negative-pair-multiple.json',p)
p=pair('auto');p['request']['mode']='guided';test('guided_action',p,False)
p=pair('auto');p['result']['data']['refresh_required']=True;test('refresh_action',p,False)
p=pair('guided');p['request']['mode']='self';test('self_highlight',p,False)
save(ROOT/'candidate/positive-pair.json',pair('auto'))
save(ROOT/'tests/pair-schema-results.json',{'passed':len(rows),'total':len(rows),'checks':rows})
print('Pair schema: 7/7')
