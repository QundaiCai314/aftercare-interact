"""Reads upstream deliverables, executes their pure checkers. No upstream writes."""
import importlib.util, json, sys, hashlib, copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'aftercare-interact/scripts'))
from validate_plan import schema_errors, validate, digest, SCHEMA
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
checks=[]
def check(name,passed,detail=None):checks.append(dict(name=name,passed=bool(passed),detail=detail))
order=BASE/'files-pasted-by-the-user-skill/outputs'
remedy=BASE/'files-pasted-by-the-user-skill-2/outputs'
evidence=BASE/'files-pasted-by-the-user-skill-3/outputs'
o=read(order/'tests/selection-positive-fixture.json')
oc=load('upstream_order_checks',order/'tests/selection_checks.py').check(o['request'],o['result'],o['host'])
check('actual_order_checker',oc['selection_valid'] and not oc['remedy_handoff'],oc)
r=read(remedy/'tests/choice-positive-fixture.json')
rc=load('upstream_remedy_checks',remedy/'tests/checks.py').check(r['request'],r['author_output'],r['host'])
check('actual_remedy_checker',rc['choice_valid'] and not rc['formal_preparation_allowed'],rc)
ea=read(evidence/'candidate/positive.json');eh=read(evidence/'tests/binding-positive-host.json')
ec=load('upstream_evidence_checks',evidence/'tests/binding_checks.py').check(ea,eh)
check('actual_evidence_checker',ec['content_review_valid'] and not ec['central_v1_handoff_allowed'] and not ec['upload_authorized'],ec)
trace=read(evidence/'tests/integration-trace.json')
v2=trace['intake_trace']['completed']['data']
check('recorded_actual_intake_v2_rejected_by_v1',bool(schema_errors(v2,'TaskIntent')),'Read retained output only; intake demo not rerun this turn; no field projection')
for name,data in [('OrderSelection',o['result']['data']),('RemedyPlan',r['author_output']['data']),('EvidenceBundle',read(evidence/'examples/result-derived.json')['data'])]:
    check('unchanged_upstream_'+name,not schema_errors(data,name))
old=read(evidence/'examples/interact-structural-only.json')
check('upstream_interact_request_shape',not schema_errors(old['request'],'aftercare-interactRequest'))
# Consume actual upstream bundle body unchanged, in a clearly synthetic host registration.
f=read(ROOT/'examples/pending-authorization.json')
bundle=read(evidence/'examples/result-derived.json')['data']
f['host']['registry']['bundle-test']['data']=copy.deepcopy(bundle)
f['host']['profile']='central-v1'
f['host']['readiness']['evidence']='unreviewed'
err=validate(f['request'],f['result'],f['host'])
check('actual_bundle_cannot_become_ready_upload',all(x in err for x in ['material_unreviewed','missing_business:evidence','production_contract_gap']),err)

# Retain a schema-valid synthetic receipt and verify request. No verify model exists here.
q=f['request'];a=f['result']['data']['actions'][0]
receipt={'execution_id':'execution-synthetic','proposal_id':a['proposal_id'],'task_id':q['task_id'],'target_item_ref':a['target_item_ref'],'action_payload_digest':digest(a),'confirmation_ref':None,'observation_id':a['observation_id'],'page_revision':a['page_revision'],'dispatch_state':'not_sent','tool_state':'not_started','started_at':'2026-09-27T12:00:00+08:00','finished_at':None,'result_evidence_refs':[]}
verify={k:v for k,v in q.items() if k!='inputs'};verify.update(skill_id='aftercare-verify',call_id='call-verify-synthetic',inputs={'platform_view':q['inputs']['platform_view'],'receipt':{'artifact_id':'receipt-test','kind':'ExecutionReceipt','revision':1},'ledger':{'artifact_id':'ledger-test','kind':'OperationLedger','revision':1}})
ledger={'task_id':q['task_id'],'ledger_revision':1,'events':[{'event_id':'event-planned','occurred_at':'2026-09-27T12:00:00+08:00','event_type':'planned','execution_ref':'receipt-test','evidence_refs':[]}]}
for name,data in [('ExecutionReceipt',receipt),('OperationLedger',ledger),('aftercare-verifyRequest',verify)]:check('downstream_shape:'+name,not schema_errors(data,name))
handoff={'synthetic':True,'not_executed':True,'receipt':receipt,'ledger':ledger,'verify_request':verify,'immutable_proposal':a,'notice':'All refs must be registered by the real host. expected_result is retained via proposal_id; v1 verify inputs do not directly contain it.'}
(ROOT/'examples/verify-structural-handoff.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2),encoding='utf-8')
provenance=read(ROOT/'aftercare-interact/references/provenance.json')
central=read(Path(provenance['sources'][0]['path']))
check('derived_definitions_equal_central',all(v==central['$defs'][k] for k,v in SCHEMA['$defs'].items()))
check('all_read_sources_unchanged',all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in provenance['sources']))
report={'method':'upstream pure checkers rerun; prior intake output read; synthetic downstream structure only','passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks,'full_positive_chain':'not_run: upstream contracts incompatible, real host/platform/verify unavailable'}
(ROOT/'tests/integration-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if report['passed']==report['total'] else 1)
