"""SYNTHETIC in-memory executor gate; intentionally has NO browser dispatch."""
from validate_plan import validate, digest

def binding(q, r, h):
    a = r['data']['actions'][0]
    ids = a['value_refs'] + [a['recipient_ref'], a['material_content_ref']]
    return digest({'request': q, 'action': a, 'epoch': h['epoch'],
                   'records': {k: h['registry'].get(k) for k in ids if k is not None}})

def business_key(q, r, h):
    a = r['data']['actions'][0]
    # Independent of proposal ID, page layout, and content modifications in the same case.
    return digest([q['task_id'], a['target_item_ref'], h['business_case'], a['operation']])

class ExecutorStub:
    def __init__(self):
        self.ledger = {}
        self.events = []

    def check_and_record(self, q, r, h, confirmation=None):
        errors = validate(q, r, h)
        if errors:
            return {'sent': False, 'errors': errors}
        if len(r['data']['actions']) != 1 or h['mode'] != 'auto':
            return {'sent': False, 'errors': ['no_auto_action']}
        a = r['data']['actions'][0]
        key = business_key(q, r, h)
        if key in self.ledger:
            return {'sent': False, 'errors': ['duplicate_or_unknown']}
        if h['write_inflight']:
            return {'sent': False, 'errors': ['task_mutex']}
        if not h['scope_allowed']:
            return {'sent': False, 'errors': ['scope']}
        if a['effect'] == 'external_write':
            if confirmation is None or confirmation.get('source') != 'synthetic_user_event' or confirmation.get('consumed') or confirmation.get('digest') != binding(q, r, h):
                return {'sent': False, 'errors': ['confirmation_required_or_stale']}
        self.events.append({'state': 'dispatch_started', 'key': key, 'proposal_id': a['proposal_id']})
        self.ledger[key] = 'sent_unknown'
        if confirmation is not None:
            confirmation['consumed'] = True
        # This marks a simulated send ONLY. No real tool is invoked, and no business success.
        self.events.append({'state': 'simulated_sent_unknown', 'key': key})
        return {'sent': True, 'simulation': True, 'business_result': 'unknown'}
